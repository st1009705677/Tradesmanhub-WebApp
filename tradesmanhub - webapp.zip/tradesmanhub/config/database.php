<?php
    require __DIR__.'/../vendor/autoload.php';
   
    use Kreait\Firebase\Factory;
    use Kreait\Firebase\Contract\Auth;

    class FirebaseConnection{
        private $factory;

        public function __construct()
        {
            $serviceAccountFilePath = '../config/tradesmanhub-ab3ba-firebase-adminsdk-65m0n-5c4672e17e.json';
            $databaseUri = 'https://tradesmanhub-ab3ba-default-rtdb.firebaseio.com/';
            $this->factory = (new Factory)
                ->withServiceAccount($serviceAccountFilePath)
                ->withDatabaseuri($databaseUri);
        }

        public function initializeFirebaseDatabase()
        {
            // Create a new Firebase Realtime Database instance
            $database = $this->factory->createDatabase();

            // Return the created database instance
            return $database;
        }

        public function initializeFirebaseAuth()
        {
            // Create a new Firebase Authentication Realtime Database instance
            $database = $this->factory->createAuth();

            // Return the created database instance
            return $database;
        }

    }
    
      

?>