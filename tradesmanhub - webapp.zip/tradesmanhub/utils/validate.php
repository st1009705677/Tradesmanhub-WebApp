<?php
class InputValidator {
    private $errors = [];

    public function validateNotEmpty($field, $value) {
        if (empty($value)) {
            $this->errors[$field] = ucfirst($field) . " cannot be empty.";
        }
    }

    public function validateEmail($field, $value) {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = ucfirst($field) . " is not a valid email address.";
        }
    }

    public function validateAlphanumeric($field, $value) {
            if (!preg_match(strval('/^[a-z0-9.]+$/i'), $value)) {
            $this->errors[$field] = ucfirst($field) . " must contain only letters and numbers.";
        }
    }

    public function validateNumeric($field, $value) {
        if (!is_numeric($value)) {
            $this->errors[$field] = ucfirst($field) . " must contain only numeric values.";
        }
    }

    public function validateLettersOnly($field, $value) {
        if (!preg_match("/^[a-zA-Z]+$/", $value)) {
            $this->errors[$field] = ucfirst($field) . " must contain only letters and no numbers or special characters.";
        }
    }

    public function validateDateNotBeforeCurrentDate($field, $value) {
        $inputDate = strtotime($value);
        $currentDate = strtotime(date('Y-m-d'));
        if ($inputDate < $currentDate) {
            $this->errors[$field] = ucfirst($field) . " cannot be before the current date.";
        }
    }

    public function validatePasswordMatch($fields, $password, $cpassword){
        if($password != $cpassword){
            $this->errors[$fields] = ucfirst($fields) . " do not match.";
        }
    }

    function clean($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
      }

    public function getErrors() {
        return $this->errors;
    }
}
?>