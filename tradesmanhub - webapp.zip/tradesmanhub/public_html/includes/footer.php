<footer class="row" style="background-color:#333333; height: 3rem;">
    <p style="color: #FFFFFF">
        &copy 2023 Designed &amp; Developed by Affixed Innovations
    </p>
</footer>