
<?php 
  include('includes/navbar.php');

  if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] ==  true){
    header('location: search.php');
    die();
  }
  require_once('../models/User.php'); 
  require_once '../utils/validate.php';

  $result = $errors = $name = $email = $password = $cpassword = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
  $validate = new InputValidator();
  if(isset($_POST['reg_btn'])){
    // Validate service
    $name = $validate->clean($_POST['name']);
    $validate->validateNotEmpty("Name", $name);
    $validate->validateLettersOnly("Name", $name);
    $email = $validate->clean($_POST['email']);
    $validate->validateNotEmpty("Email", $email);
    $validate->validateEmail("Email", $email);
    $password = $validate->clean($_POST['password']);
    $validate->validateNotEmpty("Password", $password);
    $cpassword = $_POST['confirm_password'];
    $cpassword = $validate->clean($_POST['confirm_password']);
    $validate->validateNotEmpty("Confirm password", $cpassword);
    $validate->validatePasswordMatch("Password and Confirm password", $password, $cpassword);
    $errors = $validate->getErrors();

    if(empty($errors)){
        // Handle database interactions and start sessions here

        $signedUpUser = (new UserManagement)
            ->signUpUser($name, $email, $password, $cpassword);

        if($signedUpUser){
          $_SESSION['logged_in'] = true;
          $_SESSION['logged_in_user'] = $signedUpUser;
          header('location: search.php');
          die();
        }else{
            $result = 'Failed to create your account, please try again.';
        }
    }
  }
}
?>

<?php
            if(!empty($errors)){
        ?>
        <div class="error-display">
            <?php
            foreach($errors as $error){
            ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <?php echo $error; ?>   
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php
            }
            ?>
        </div>

        <?php
        }
        ?>
  <div class="row" style="max-height:50vh;">
    <div class="col-sm-12 col-md-6 col-lg-6">
      <img src="images/dashboard-07.png" style="height:100%; width:100%;" alt=""/>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-6 mt-5" style="text-align:start;">
      <h5 class="display-4">Create an account</h5>
      <?php
          if($result){
        ?>
          <div class="row">
            <div class="alert alert-dark col-sm-12 col-md-6 col-lg-6" role="alert">
              <?=$result;?>
            </div>
          </div>
        <?php 
            }
        ?>
      <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
          <div class="row form-group">
            <label class="form-label" for="name">Name</label>
            <input type="text" name="name" class="form-control col-8" id="name">
          </div>
          <div class="row form-group">
            <label class="form-label" for="Email">Email</label>
            <input type="email" name="email" class="form-control col-8" id="Email">
          </div>
          <div class="row form-group">
            <label class="form-label"  for="Password">Password</label>
            <input type="password" name="password" class="form-control col-8" id="Password" >
          </div>
          <div class="row form-group">
            <label class="form-label" for="ConfirmPassword">Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control col-8" id="ConfirmPassword" >
          </div>
          <div class="row form-group">
            <button type="submit" name="reg_btn" class="login-btn col-4">Register</button>
            <p class="lead">Already have an account? <a href="login.php">Login</a></p>
          </div>
      </form>
    </div>
  </div>

<map name="Map">
  <area shape="rect" coords="1,-1,253,60" href="Home.html">
</map>
</body>
</html>
