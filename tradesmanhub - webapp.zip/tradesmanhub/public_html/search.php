
<?php 

$title = 'TradesmanHub | Search';
include('includes/navbar.php'); 


$query = '';
$results = [];

if(isset($_GET['query'])){
  require_once '../models/SearchAndMatch.php';
  $query = $_GET['query'];

  $results = (new SearchAndMatch)
    ->searchByService();
}

// Pass $results to javascript
echo '<script>var searchResults = ' . json_encode($results) . ';</script>';

?>


<div class="row split_view">
  <!-- <div class="side_nav">
    <div class="row filters">
        <h6>Filter</h6>
        <div class="row form-group">
          <label for="rating" class="form-label">Rating</label>
          <select name="rating" class="form-control" placeholder="Rating">
            <option selected value="">All</option>
            <option value="1">1</option>
          </select>
        </div>
    </div>
  </div> -->
  <div class="main_display" style="width:100%;">
    <form method="get" action="">
      <div class="search_bar">
        <input class="form-control col-md-6" type="text" name="query" value="<?=$query?>" placeholder="Search for a service">
        <button type="submit" class="btn btn-light"><i class="ri-search-line"></i></button>
      </div>
    </form>
    <div class="search_results" id="search_results">
      <a href="provider.php?<?=$service_provider_id?>">
        <div class="search_item_result card">
            <!-- Image url comes here -->
            <img src="images/place_holder.png" class="display_picture">
          <div class="search_item_details">
            <h5 class="sp-name">Ikageng Tladi</h5>
            <span class="lead service">Software Developer</span>
            <p class="description">
              I specialize in providing end to end IT Services that range from starting 
              your online presence by registering a good domain to marketing your products 
              online including everything in between like designing/developing eye catching 
              website.
            </p>
          </div>
        </div>
      </a>
    </div>
</div>
   

<script>
  var resultsContainer = document.getElementById("search_results");

  function generateResultHTML(serviceProviderId, name, serviceType, description) {
    var resultHTML = `<a href="provider.php?${serviceProviderId}">
        <div class="search_item_result card" style="flex-direction: row;">
          <!-- Image url comes here -->
          <img src="images/place_holder.png"  class="display_picture">
          <div class="search_item_details">
            <h5 class="users_name">${name}</h5>
            <span class="lead service">${serviceType}</span>
            <p class="description">
              ${description}
            </p>
          </div>
        </div>
      </a>`;
    return resultHTML;
  }
  // Filter and displa results based on the query
  function filterAndRenderResults(query) {
    resultsContainer.innerHTML = '';

    for (var serviceType in searchResults) {
      var providers = searchResults[serviceType];
      for (var providerId in providers) {
        var provider = providers[providerId];

        // check if the providers name or service matches the query
        if (provider.name.toLowerCase().includes(query.toLowerCase()) || 
            serviceType.toLowerCase().includes(query.toLowerCase())) {
          var resultHTML = generateResultHTML(providerId, provider.name, serviceType, provider.description);

          // Add the generated html to the results container
          resultsContainer.innerHTML += resultHTML;
        }
      }
    }
  }

  // Call the filterAndRenderResults when the page loads or when the user submits the search form
  filterAndRenderResults('<?php echo $query; ?>');
</script>
</body>
</html>

