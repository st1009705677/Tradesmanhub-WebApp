<?php
session_start();

if(!isset($_SESSION['logged_in'])){
    if(!isset($_SESSION['logged_in'])){
        header('location: login.php');
        die();
    }
}

require_once '../models/DataModel.php';
?>

<!doctype html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- Remix icons -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

        <!-- CSS imports -->
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/bootstrap-4.4.1.css" rel="stylesheet" type="text/css">

        <!-- Javascript imports -->
        <script src="js/jquery-3.4.1.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap-4.4.1.js"></script>

        <style>
            .form-group{
                width: 100%;
            }
            .btn-sm{
                font-size: small !important;
                padding: .2rem .5rem !important;
            }
            .btn-search:hover{
                background-color: rgba(158, 42, 43, 0.5) !important;
            }
            .row{
                height: 100vh;
                align-items: center;
                justify-content: center;
            }
            body{
                text-align: start;
            }
            .spinner-border{
                position: absolute;
                top: 50%;
                left: 50%;
                background-color: rgba(255, 255, 255, 0.5);
            }
            @media (max-width: 425px) {
                .display-4{
                    font-size: 28px;
                }
            }
        </style>
    </head>
    <body id="body">
        <div class="row my-5">
            <div class="new-post-container col-sm-12 col-md-6 col-lg-6">
                <div class="w-100" style="text-align:start;">
                    <a href="#" onclick="history.back()"><i class="ri-arrow-left-s-line"></i>&ensp;Back</a>
                </div>
                <div class="w-100" >
                    <h1 class="display-4 mb-1">Tell us more about yourself</h1>
                </div>
                <form name="myForm" method="post" action="">               
                    <div class="form-row">
                        <div class="form-group col-12">
                            <label class="form-label col-form-label-sm">What is your full name?</label>
                            <input name="provider" type="text" class="form-control form-control-sm" id="">
                        </div>
                    </div>
                    <div class="form-row">  
                        <div class="form-group col-sm-12 col-md-6">
                            <label class="form-label col-form-label-sm">What your date of birth?</label>
                            <input name="birth-date" type="date" class="form-control form-control-sm" >
                        </div>
                        <div class="form-group col-sm-12 col-md-6">
                            <label class="form-label col-form-label-sm">Where are you situated?</label>
                            <input name="location" type="text" class="form-control form-control-sm">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-12 col-md-6">
                            <label class="form-label col-form-label-sm">What service would you like to provider?</label>
                            <input name="is-qualified" type="text" class="form-control form-control-sm">
                        </div>
                        <div class="form-group col-sm-12 col-md-6">
                            <label class="form-label col-form-label-sm">Are you qualified to provider the service</label>
                            <select name="service" class="form-control custom-select-sm">
                                <option value="">Select an option</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-12 col-md-12">
                            <label class="form-label col-form-label-sm">if yes, where did you obtain your qualification?</label>
                            <input name="institution" type="text" class="form-control form-control-sm">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-12 col-md-12">
                            <label class="form-label col-form-label-sm">Description your service in detail</label>
                            <textarea name="description" class="form-control form-control-sm" row="5"></textarea>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-sm-12 col-md-12">
                            <label class="form-label col-form-label-sm">Supporting documents</label>
                            <div class="input-group input-group-sm">
                                <input type="file" class="form-control-sm" name="fileToUpload" id="fileToUpload">                                
                                <div class="input-group-append">
                                <div class="input-group-text"><a href="#" onclick="saveFile()"><i class="ri-save-line"></i></a></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-sm-12 col-md-6">                         
                            <div id="savedFile" style="font-size:16px;" class="mt-2"></div>
                        </div>
                    </div>
                    <div class="form-row">
                        <button type="submit" class="btn btn-sm search-btn col-sm-12 col-md-2 col-lg-2" name="post-job">Submit</button>
                    </div>
                </form>
            </div>
        </div>

        <div id="loadingSpinner" class="spinner-border text-primary" role="status" style="display: none" >
            <span class="sr-only">Loading...</span>
        </div>
    </body>
</html>


<script>
    function saveFile() {
        var fileInput = document.getElementById('fileToUpload');
        var file = fileInput.files[0];

        if (file) {
            // Here, you can send the selected file to the server using AJAX or perform any other necessary action.
            // For demonstration purposes, let's display the file name and an option to remove it.
            var savedFileDiv = document.getElementById('savedFile');
            var fileName = file.name;

            var fileContainer = document.createElement('div');
            fileContainer.className = 'd-flex justify-content-between align-items-center';
            
            var fileNameDiv = document.createElement('div');
            fileNameDiv.textContent = fileName + "  ";
            
            var removeButton = document.createElement('i');
            removeButton.textContent = '';
            removeButton.className = 'btn-light ri-delete-bin-line';
            removeButton.onclick = function() {
                savedFileDiv.removeChild(fileContainer);
            };

            fileContainer.appendChild(fileNameDiv);
            fileContainer.appendChild(removeButton);
            savedFileDiv.appendChild(fileContainer);

            // Clear the file input after saving the file (optional)
            fileInput.value = '';
        } else {
            alert('Please select a file before saving.');
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
    document.forms['myForm'].addEventListener('submit', function(event) {
        // Prevent the form from submitting immediately
        event.preventDefault();

        // Display the loading spinner
        var loadingSpinner = document.getElementById('loadingSpinner');
        loadingSpinner.style.display = 'block';
        document.body.style.background = 'rgba(255, 255, 255, 0.5)';

        // After 3 seconds, replace the contents with a new message
        setTimeout(function() {
            loadingSpinner.style.display = 'none';
            document.body.style.background = 'initial';
            var formContainer = document.querySelector('.new-post-container');
            formContainer.innerHTML = '<div class="row" style="height:100vh; flex-direction:column;">' +
                '<h3 class="display-4">Congratulations</h3>' +
                '<p>Your request was well received, please be patient while we get back to you.</p>' +
                '<p class="lead">You will be redirected shortly, if not click <a href="search.php" style="color:blue;">here</a></p>' +
                '</div>';

            // After another 3 seconds, redirect to another page
            setTimeout(function() {
                window.location.href = 'redirect_page.php'; // Replace 'redirect_page.php' with the actual URL you want to redirect to
            }, 3000);
        }, 3000);
    });
});
</script>