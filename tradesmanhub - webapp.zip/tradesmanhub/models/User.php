<?php
require_once('DataModel.php');

class UserManagement
{
    private $DataModel;
    private $errors = [];
    private $users;
    public $uid;
    public $displayName;
    public $email;
    public $contactNumber;
    public $claims;
    
    function __construct(){
        $this->DataModel = new DataModel();
    }

    function signUpUser($fname, $email, $password, $cpassword){

        if ($password !== $cpassword)
        {
            $this->errArr['pwdMatchErr'] = 'Passwords do not match';
            return false;
        }
    
        // check if the email exists
        $userExists = $this->DataModel->searchUserByEmail($email);

        if ( $userExists ){
            array_push($this->errors, 'Email exists');
            return false;
        }

        // create new user
        $createdUser = $this->DataModel->createUser($fname, $email, $password);

        if( $createdUser ){
            $path = "users/$createdUser/";
            $properties = [
                'email' => $email,
                'displayName' => $fname,
            ];
            $this->DataModel
                ->addRecord($path, $properties);

            // Log user in 
            $signedInUser = $this->signInUser($email, $password);
            // $this->sendEmailVerification($email);   // send a verification email
            return $signedInUser;
        }

        array_push($this->debug, 'Failed to create user');
        return false;
    }

    // Sign user in with email and password
    function signInUser($email, $password){
        $user = $signInResult = null;

            $userExists = $this->DataModel->searchUserByEmail($email);

        if( $userExists ){

            $signInResult = $this->DataModel->signInWithEmailAndPassword($email, $password);
            return $signInResult;
        }else{
            array_push($this->errors, 'Incorrect email.');
        }
        return false;
    }

    function requestServProvAccount($uid, $documents = []){
        // set role to pending
        $setClaim = $this->DataModel->setuserClaims($uid, ["role" => ['customer', 'pending']]);
        // path to store request
        $path = "users/$uid/documents/";
        // store request
        $storedRecord = $this->DataModel->addRecord($path, $documents);

        return $storedRecord;
    }

    function getRequests($uid){
        $path = "/users/$uid/requests";
        $requests = $this->DataModel->getRecords($path);
        $requestsArr = [];
        
        foreach($requests as $rid => $status){
            $path = "requests/$rid";
            $currentRequest = $this->DataModel->getRecords($path);
            if($currentRequest){
                $requestsArr[$rid] = [
                    'id' => $currentRequest['request_id'],
                    'spid' => $currentRequest['servprov_id'],
                    'name' => $currentRequest['serprov_name'],
                    'service' => $currentRequest['service_type'],
                    'description' => $currentRequest['description'],
                    'location' => $currentRequest['location'],
                    'status' => $status
                ];
            }
        }

        return $requestsArr;
    }

    function updateUserClaim($option, $uid){
        // set user claim
        if($option == 'customer'){
            $setClaim = $this->DataModel->setuserClaims($uid, ["role" => 'customer']);
            return $setClaim;
        }elseif($option == 'servprov'){
            $setClaim = $this->DataModel->setuserClaims($uid, ["role" => ['customer', 'service provider']]);
            return $setClaim;
        }elseif($option == "administrator"){
            $setClaim = $this->DataModel->setuserClaims($uid, ["role" => ['customer', 'administrator']]);
            return $setClaim;
        }

        return false;
    }

    function UpdateUserRecord($uid){
        $updatedUser = $this->DataModel->updateUserRecord($uid);
        return $updatedUser;
    }

    function getUserRecord($uid){
        $user = $this->DataModel->searchUserById($uid);
        return $user;
    }

    function queryUsers(){
        $this->users = $this->DataModel->queryUsers();
        return $this;
    }    

    // queryUsers chain function
    function byClaims($filterClaim = 'customer'){
        $arrOfUsers = [];

        if(isset($this->users)){
            foreach ($this->users as $user => $data) {
                if (isset($data['claims']['role'])) {
                    $role = $data['claims']['role'];
                    
                    if (is_array($role) && in_array($filterClaim, $role)) {
                        $arrOfUsers[$user] = $data;
                    } elseif ($role == $filterClaim) {
                        $arrOfUsers[$user] = $data;
                    }
                }
            }
            return $arrOfUsers;
        }

        return false;
    }

    // queryUsers chain function
    function getAll(){
        if(isset($this->users))
        {
            return $this->users;
        }
        return false;
    }

    // Sends an email verification link
    function sendEmailVerification($email){
        $emailVerification = $this->DataModel->auth->sendEmailVerificationLink($email);
        return $emailVerification;
    }

    // Sends a password reset link
    function passwordReset($email){
        $resetPassword = $this->DataModel->auth->sendPasswordResetLink($email);
        return $resetPassword;
    }

    // Changes user email
    function changeEmail($uid, $newEmail){
        $updatedUser = $this->DataModel->auth->changeUserEmail($uid, $newEmail);
    }

    function disableAccount($uid){
        $updatedUser = $this->DataModel->auth->disableUser($uid);
        return $updatedUser;
    }

    function setCurrentUser($user){
        $this->uid = $user->uid;
        $this->displayName = $user->displayName;
        $this->email = $user->email;
        $this->contactNumber = $user->phoneNumber;
        $this->claims = $user->customClaims;
    }

    // Retrieve the error array
    function getErrors(){
        if( !is_null($this->errArr) && isset($this->errArr) ){
            return $this->errArr;
        }
        return null;
    }
}