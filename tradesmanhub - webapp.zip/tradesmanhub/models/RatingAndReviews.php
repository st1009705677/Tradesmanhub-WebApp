<?php
require_once('DataModel.php');
require_once('User.php');

class RatingAndReviews{
    private $DataModel;
    public $rating;
    public $comment;
    public $date;
    public $reviewer;
    public $reviewee;
    public $jobId;

    function __construct(){
        $this->DataModel = new DataModel();

        // set a date variable
        $this->date = date('d/m/Y');
    }

    function createReview(?float $rating, ?string $comment, ?string $reviewer, ?string $reviewee, ?string $jobId){
        // declare variables
        $path = 'reviews/';
        $properties = [
            'rating' => $rating,
            'comment' => $comment,
            'from' => $reviewer,
            'date' => $this->date,
            'jobId' => $jobId,
        ];

        // push the variables into the database
        $pushedReviewKey = $this->DataModel->pushRecord($path, $properties);

        // set new path and properties
        $path = "users/$this->reviewee/reviews";
        $properties = [
            $pushedReviewKey => true,
        ];
        
        // add the record to the servprov profile
        $savedToServProv = $this->DataModel->addRecord($path, $properties);

        return $savedToServProv;
    }

    function getServProvReviews($uid){
        // create a path variable
        $path = "users/$uid/reviews/";
        $reviewKeys =array();

        //retrieve all reviews for the user
        $reviews = $this->DataModel->getRecords($path);
        
        
        //check that they are all true
        foreach($reviews as $reviewID=>$isTrue){
            if($isTrue === true)
                array_push($reviewKeys, $reviewID);
        }

        // create a new path
        $path = 'reviews/';

        // look up the reviews in the reviews node
        $reviews = $this->DataModel->getRecords($path);
        $keysMatching = array_intersect($reviewKeys, array_keys($reviews));

        foreach($keysMatching as $key)
            $reviewsList[$key] = $reviews[$key];

        return $reviewsList;
    }
}
