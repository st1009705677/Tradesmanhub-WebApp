<?php
require_once('DataModel.php');

class RequestManager
{
    private $DataModel;
    
    function __construct(){
        $this->DataModel = new DataModel();
    }

    function postJob($uid, $service, $start_date, $budget, $address, $description){
        // Set path and properties
        $path = "posts/";
        $properties = [
            'client' => $uid,
            'service' => $service,
            'start_date' => $start_date,
            'budget' => $budget,
            'address' => $address,
            'description' => $description,
            'isAssigned' => false,
        ];

        // Push the record into the database and get the key
        $pushedRecord = $this->DataModel->pushRecord($path, $properties);

        // Set new path to user profile and properties
        $path = "users/$uid/posts/";
        $properties = [$pushedRecord => 'pending'];
        
        // Record the users post
        $addedRecord = $this->DataModel->addRecord($path, $properties);

        return $addedRecord;

    }

    function requestService($uid, $provider, $service, $start_date, $budget, $address, $description){
        // Set path and properties
        $path = "requests";
        $currentDate = date('Y-m-d');
        $properties = [
            'client' => $uid,
            'provider' => $provider,
            'service' => $service,
            'dates' => [
                'request_date' => $currentDate,
                'start_date' => $start_date,
                ],
            'budget' => $budget,
            'address' => $address,
            'description' => $description,
        ];

        // Push the record into the database and get the key
        $pushedRecord = $this->DataModel->pushRecord($path, $properties);

         // Set new path to client profile and properties
         $path = "users/$uid/requests/";
         $properties = [$pushedRecord => 'pending'];
         
         // Record the users post
         $addedRecord = $this->DataModel->addRecord($path, $properties);

          // Set new path to providers profile and properties
        $path = "users/$provider/requests/";
        $properties = [$pushedRecord => 'pending'];
        
        // Record the users post
        $addedRecord = $this->DataModel->addRecord($path, $properties);

    }

    
    function getPosts($uid){
        $path = "/users/$uid/posts";
        $posts = $this->DataModel->getRecords($path);
        $postArr = [];
        if($posts)
            foreach($posts as $pid => $status){
                $path = "posts/$pid";
                $client = $provider = "";
                $currentPost = $this->DataModel->getRecords($path);
                if($currentPost){
                    if($currentPost['isAssigned'] == true){
                        $client = $this->DataModel->getRecords("users/".$currentPost['client']."/displayName");
                        $provider = $this->DataModel->getRecords("users/".$currentPost['provider']."/displayName");
                    }
                    $postArr[$pid] = [
                        'receipt_no' => "Receipt number",
                        'client' => $client,
                        'provider' => $provider,
                        'service' => $currentPost['service'],
                        'description' => $currentPost['description'],
                        'address' => $currentPost['address'],
                        'status' => $status,
                        'start_date' => $currentPost['start_date'],
                        'isAssigned' => $currentPost['isAssigned'],
                    ];
                }
            }
        return $postArr;
    }


    function getSinglePost($pid, $status){
        // Path
        $path = "posts/$pid";
        $client = $provider = "";
        
        $post = $this->DataModel->getRecords($path);
        if($post){
            if($post['isAssigned'] == true){
                $client = $this->DataModel->getRecords("users/".$post['client']."/displayName");
                $provider = $this->DataModel->getRecords("users/".$post['provider']."/displayName");
            }
            $postArr[$pid] = [
                'receipt_no' => "Receipt number",
                'client' => $client,
                'provider' => $provider,
                'service' => $post['service'],
                'description' => $post['description'],
                'address' => $post['address'],
                'status' => $status,
                'start_date' => $post['start_date'],
                'isAssigned' => $post['isAssigned'],
            ];
        }
        return $postArr;
    }

    function getRequests($uid){
        $path = "/users/$uid/requests";
        $requests = $this->DataModel->getRecords($path);
        $requestsArr = [];
        
        if($requests)
            foreach($requests as $rid => $status){
                $path = "requests/$rid";
                $currentRequest = $this->DataModel->getRecords($path);
                if($currentRequest){
                    $client = $this->DataModel->getRecords("users/".$currentRequest['customer_id']."/displayName");
                    $provider = $this->DataModel->getRecords("users/".$currentRequest['servprov_id']."/displayName");
                    $requestsArr[$rid] = [
                        'receipt_no' => "Receipt number",
                        'client' => $client,
                        'provider' => $provider,
                        'service' => $currentRequest['service_type'],
                        'description' => $currentRequest['description'],
                        'location' => $currentRequest['location'],
                        'dates' => $currentRequest['dates'],
                        'status' => $status
                    ];
                }
            }
        return $requestsArr;
    }

    function jobListings($service){
        // Set the path
        $path = "posts";
        $postsArr = [];
        
        // Get posts
        $posts = $this->DataModel->getRecords($path);

        if($posts){
            foreach($posts as $post => $data){
                if($data['isAssigned'] == false){
                    $client = $this->DataModel->getRecords("users/".$data['client']."/displayName");

                    $postsArr[$post] = [
                        'receipt_no' => "Receipt number",
                        'client' => $client,
                        'service' => $data['service'],
                        'description' => $data['description'],
                        'address' => $data['address'],
                        'start_date' => $data['start_date'],
                        'isAssigned' => $data['isAssigned'],
                    ];
                    // if($data['service'] == $service){
                    // }
                }
            }   
        }
        
        return $postsArr;
    }

}