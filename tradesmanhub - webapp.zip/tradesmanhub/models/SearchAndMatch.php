<?php
require_once('DataModel.php');
// include the database configuration


class SearchAndMatch
{
    public $database;
    public $auth;
    private $debug = [];

    function __construct(){
        $this->DataModel = new DataModel();
    }

    function searchByService(){

        // create a path string and get the relevant service providers
        $path = "services";
        $results = $this->DataModel->getRecords($path);
        
        return $results;
    }
   
}
