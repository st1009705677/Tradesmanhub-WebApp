<?php
require __DIR__.'/../config/database.php';
// include the database configuration

class DataModel{
    public $database;
    public $auth;
    private $debug = [];

    public function __construct() {
        // initialize objects of the database
        $this->database = (new FirebaseConnection()) // intialize database connection
                        ->initializeFirebaseDatabase();
        $this->auth = (new FirebaseConnection()) // intialize auth database connection
                        ->initializeFirebaseAuth();
    }

    function createUser($fname, $email, $password){
        // create a properties array
        $properties = [
            'displayName' => $fname,
            'email' => $email,
            'password' => $password,
        ];
        // create new user
        $createdUser = $this->auth->createUser($properties);
        $uid = $createdUser->uid;
        // return result
        return $uid;
    }
    
    function signInWithEmailAndPassword($email, $password){
        try{
            // sign in user
            $signInResult = $this->auth->signInWithEmailAndPassword($email, $password);
            
            if( $signInResult ){
                $signedInUser = $this->searchUserByEmail($email);
                $uid = $signedInUser->uid;
                return $uid;
            }
        }catch(Exception $e){
            array_push($this->debug, 'Incorrect password');
        }
        return false;
    }
    
    function updateUserRecord($uid, $propArray){
        // Return if parameter is not a string
        if(!is_array($propArray)){
            return;
        }
        
        try{
            $updatedUser = $this->auth->updateUser($uid, $propArray);
            return ( $updatedUser ) ? $this->searchUserById($uid) : false;
        }catch(Exception $e){
            push_array($this->debug, 'Failed to update details, please try again');
        }
        return false;   
    }

    function queryUsers(){
        $users = $this->auth->listUsers($defaultMaxResults = 1000, $defaultBatchSize = 1000);
        
        // foreach( $users as $user){
        //     $listOfUsers[$user->uid] = [
        //         'username' => $user->displayName,
        //         'email' => $user->email,
        //         'claims' => $this->auth->getUser($user->uid)->customClaims,
        //     ];
        // }
        return $users;
    }

    function searchUserByEmail(?string $email){
        // look up user by email
        try{
            $user = $this->auth->getUserByEmail($email);
            return $user;
        }catch(Exception $e){
            array_push($this->debug, "Email does not exist");
        }
        
        return false;
    }

    private function setCurrentUser($user){
        $currentUser = new UserManagement();
        $currentUser->uid = $user->uid;
        $currentUser->displayName = $user->displayName;
        $currentUser->email = $user->email;
        $currentUser->contactNumber= $user->phoneNumber;
        $currentUser->claims = $user->customClaims;
        
        return $currentUser;
    }

    function addRecord(?string $strPath, $properties = []){
        $postRef = $this->database->getReference($strPath)->update($properties);
        return $postRef;
    }

    function pushRecord(?string $strPath, $properties = []){
        $postRef = $this->database->getReference($strPath)->push($properties)->getKey();
        return $postRef;
    }

    function getRecords($path){
        $reference = $this->database->getReference($path);
        $value = $reference->getValue();
        return $value;
    }

    function getKeys($path){
        $reference = $this->database->getReference($path);
        $value = $reference->getChildKeys();
        return $value;
    }

    function searchUserById($uid){
        try {
            $user = $this->auth->getUser($uid);
            // $userInfo = [
            //     'uid' => $user->uid,
            //     'username' => $user->displayName,
            //     'email' => $user->email,
            //     'phoneNumer' => $user->phoneNumber,
            //     'claims' => $this->getUserClaims($user->uid)
            // ];
            return $user;
        } catch (Exception $e) {
            array_push($this->array, "User doesn't exist");
        }
        return false;
    }

    function setuserClaims($uid, $claim){
        $setUserClaims = $this->auth->setCustomUserClaims($uid, $claim);
        return ( $setUserClaims ) ? $setUserClaim : false;
    }

    function getUserClaims($uid){
        $getUserClaims = $this->auth->getUser($uid)->customClaims;
        return $getUserClaims;
    }
}
